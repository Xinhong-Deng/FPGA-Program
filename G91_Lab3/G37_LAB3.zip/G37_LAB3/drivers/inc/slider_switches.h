#ifndef	__SLIDER_SWITCHES
#define __SLIDER_SWITCHES

	extern int read_slider_switches_ASM();

#endif
