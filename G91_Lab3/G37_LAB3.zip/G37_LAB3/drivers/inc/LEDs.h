#ifndef	__LED
#define __LED

	extern int read_LEDs_ASM();
	extern int write_LEDs_ASM(int val);

#endif

