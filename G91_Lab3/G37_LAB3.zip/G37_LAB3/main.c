
#include <stdio.h>

#include "./drivers/inc/LEDs.h"
#include "./drivers/inc/slider_switches.h"
#include "./drivers/inc/HEX_displays.h"
#include "./drivers/inc/pushbuttons.h"
#include "./drivers/inc/HPS_TIM.h"
#include "./drivers/inc/int_setup.h"
#include "./drivers/inc/ISRs.h"
int main() {
	/*
    while (1) {
        HEX_flood_ASM(HEX0);
        HEX_write_ASM(HEX1, 2 + 48);
     }
    */
	
	/*
    //HEX Display & Pushbutton
    while (1) {
        write_LEDs_ASM(read_slider_switches_ASM());     //turn on LED when switch on

		
        //clear all the HEX displays if slider switch SW9 is on
        if (0x200 & read_slider_switches_ASM()) {
            HEX_clear_ASM(HEX0);
			HEX_clear_ASM(HEX1);
			HEX_clear_ASM(HEX2);
			HEX_clear_ASM(HEX3);
			HEX_clear_ASM(HEX4);
			HEX_clear_ASM(HEX5);
			//HEX_clear_ASM(HEX0 |HEX1|HEX2|HEX3|HEX4|HEX5);
			
        }
        else {
            HEX_flood_ASM(HEX4); //Switch on all the segments of HEX4 and HEX5
			HEX_flood_ASM(HEX5);
            char val = 0xF & read_slider_switches_ASM();        //number that we want to display
            val = val + 48;  //convert to acsii
            int pushbutton = 0xF & read_PB_data_ASM(); //the pushed button
            HEX_write_ASM(pushbutton, val); //display the number
            
            }
    }
	*/
     
    
   /* //HPS stopwatch 
    
     HPS_TIM_config_t hps_tim;
     hps_tim.tim = TIM0;			//use timer 0 to run the stopwatch
     hps_tim.timeout = 10000;
     hps_tim.LD_en = 1;
     hps_tim.INT_en = 0;
     hps_tim.enable = 1;
     HPS_TIM_config_ASM(&hps_tim);
     
     HPS_TIM_config_t hps_tim_pb;
     
     hps_tim_pb.tim = TIM1;   //use TIM1 to check if button is pressed
     hps_tim_pb.timeout = 8000;
     hps_tim_pb.LD_en = 1;
     hps_tim_pb.INT_en = 0;
     hps_tim_pb.enable = 1;
     
     HPS_TIM_config_ASM(&hps_tim_pb);
	 int ms = 0,  sec = 0, min = 0, timer_start = 0; //initialize counters
     
     while(1){          //count the number on display
        if(HPS_TIM_read_INT_ASM(TIM0) && timer_start){ //read the bit S in the Interrupt status
            HPS_TIM_clear_INT_ASM(TIM0);        //reset the S and F bit
            ms = ms + 1;
            if(ms >= 100){     //if reach 100, we increment second
                sec ++;
                ms -= 100;
                if(sec  >= 60){
                    min++;
                    sec  -= 60;
					if (min >= 60) {
						min = 0;
					}
                }

            }
     
        }
        HEX_write_ASM(HEX0, (ms % 10) + 48);     //number displayed
        HEX_write_ASM(HEX1, (ms / 10) + 48);
        HEX_write_ASM(HEX2, (sec % 10) + 48);
        HEX_write_ASM(HEX3, (sec / 10) + 48);
        HEX_write_ASM(HEX4, (min % 10) + 48);
        HEX_write_ASM(HEX5, (min / 10) + 48);
     
     
        if(HPS_TIM_read_INT_ASM(TIM1)){ //continuouslly check whether stopwatch should count, reset or pause
            HPS_TIM_clear_INT_ASM(TIM1);
            if(PB_data_is_pressed_ASM(PB0)){    //start timer
                timer_start = 1;
            }
            if(PB_data_is_pressed_ASM(PB1)){    //stop timer
                timer_start = 0;
            }
            if(PB_data_is_pressed_ASM(PB2)){    //reset timer
                ms = sec = min = timer_start = 0;
            }
     }
     
}
     
     */
    


     //Interrupt
	int ms = 0, sec = 0, min = 0, timer_start = 0;
	int_setup(2, (int []){199,73});         //enable the timer interrupt    73 - key interrup id
	enable_PB_INT_ASM(PB0|PB1|PB2);
	
	HPS_TIM_config_t hps_tim;
    hps_tim.tim = TIM0;		//use timer0 for the stopwatch 
	hps_tim.timeout = 10000;
	hps_tim.LD_en = 1;
	hps_tim.INT_en = 1;
	hps_tim.enable = 1;
	HPS_TIM_config_ASM(&hps_tim);
	

	while(1){
		if(hps_tim0_int_flag && timer_start){
			hps_tim0_int_flag = 0;
			ms++;
			if(ms >= 100){              //if ms reaches 100, increment sec by 1
				sec++;
				ms = ms - 100;
				if(sec >= 60){
					min++;
					sec = sec - 60;
				}

			}
		}
		HEX_write_ASM(HEX0, (ms % 10)+48);          //number displayed on the 7-segment display
		HEX_write_ASM(HEX1, (ms / 10)+48);
		HEX_write_ASM(HEX2, (sec % 10)+48);
		HEX_write_ASM(HEX3, (sec / 10)+48);
		HEX_write_ASM(HEX4, (min % 10)+48);
		HEX_write_ASM(HEX5, (min / 10)+48);

		if(pb_int_flag){
			if(pb_int_flag & 1){            //start the stopwatch
				timer_start = 1;
			}
			else if(pb_int_flag & 2){      //pause the stopwatch
				timer_start = 0;
			}
			else if(pb_int_flag & 4){      //reset the stopwatch
				ms = sec = min = timer_start = 0;           //reset everything
			}
			pb_int_flag = 0;
		}
		
	}

	
}

